//
//  WelcomeScene.h
//  philips
//
//  Created by zhuchao on 2017/7/31.
//  Copyright © 2017年 zhuchao. All rights reserved.
//

#import "Scene.h"

@interface WelcomeScrollView : UIScrollView

-(void)loadImages:(NSArray *)list;
@end


