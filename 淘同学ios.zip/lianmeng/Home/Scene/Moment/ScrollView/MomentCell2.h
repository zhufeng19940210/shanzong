//
//  MomentCell2.h
//  lianmeng
//
//  Created by zhuchao on 2018/7/1.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MomentListModel.h"
@interface MomentCell2 : UITableViewCell
-(void)setModel:(MomentModel *)model;
@end
