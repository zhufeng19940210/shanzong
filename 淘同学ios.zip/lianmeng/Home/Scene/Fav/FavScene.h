//
//  FavScene.h
//  lianmeng
//
//  Created by zhuchao on 2018/6/19.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "Scene.h"

@interface FavScene : Scene

@end
