//
//  ProfitContenView.h
//  lianmeng
//
//  Created by zhuchao on 2018/6/23.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProfitModel.h"

@interface ProfitContenView : UIView
-(void)reloadData:(ProfitModel *)model;
@end
