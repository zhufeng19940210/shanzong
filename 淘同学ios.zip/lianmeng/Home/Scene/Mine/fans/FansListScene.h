//
//  FansListScene.h
//  lianmeng
//
//  Created by zhuchao on 2018/6/27.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "Scene.h"

@interface FansListScene : Scene
@property(nonatomic,retain)NSNumber *type;
@end
