//
//  MineCellView.h
//  lianmeng
//
//  Created by zhuchao on 2018/6/21.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MineCellView : UIView

-(instancetype)initWithImage:(UIImage *)image title:(NSString *)title;
@end
