//
//  RankScrollView.h
//  lianmeng
//
//  Created by zhuchao on 2018/6/22.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "SceneScrollView.h"

@interface RankScrollView : SceneScrollView
-(void)reloadList:(NSMutableArray *)list;
@end
