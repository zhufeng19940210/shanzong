//
//  MineHeaderView.h
//  lianmeng
//
//  Created by zhuchao on 2018/6/20.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginModel.h"

@interface MineHeaderView : UIView
-(void)setData:(LoginModel *)model;
@end
