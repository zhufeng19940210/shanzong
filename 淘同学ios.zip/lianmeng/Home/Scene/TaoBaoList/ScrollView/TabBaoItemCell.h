//
//  TabBaoItemCell.h
//  lianmeng
//
//  Created by zhuchao on 2018/6/14.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GoodsListModel.h"

@interface TabBaoItemCell : UITableViewCell
-(void)setModel:(GoodsModel *)model;
@end
