//
//  TaoBaoListScene.h
//  lianmeng
//
//  Created by zhuchao on 2018/6/13.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "Scene.h"

@interface TaoBaoListScene : Scene
@property(nonatomic,assign)NSUInteger platformId;
@end
