
#import <UIKit/UIKit.h>
#import <EasyIOS/EasyIOS.h>
#import "GoodsListModel.h"

@interface ShareDetailView : UIView
-(void)reloadData:(GoodsModel *)model;
@end
