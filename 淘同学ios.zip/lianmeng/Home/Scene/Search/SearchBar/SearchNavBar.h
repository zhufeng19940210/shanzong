
#import <UIKit/UIKit.h>
#import <EasyIOS/EasyIOS.h>

@interface SearchNavBar : UIView
@property(nonatomic,strong)UIButton *leftButton;
@property(nonatomic,strong)UIButton *dropDownButton;
@property(nonatomic,strong)UIImageView *pinkArrow;
@property(nonatomic,strong)UITextField *textField;
@end
	
