//
//  GoodsCollectionView.m
//  lianmeng
//
//  Created by zhuchao on 2018/6/6.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "GoodsCollectionView.h"
#import "GoodsCollectionViewCell.h"
#import "LikeCollectionViewCell.h"
#import "HeaderView.h"
#import "LikeView.h"
#import <EasyIOS/EasyIOS.h>
#import "CategoryListScene.h"

#import "XianShiScene.h"
#import "DetailScene.h"

@interface GoodsCollectionView()<UICollectionViewDelegate,UICollectionViewDataSource>
@property(nonatomic,retain)NSArray *list;
@property(nonatomic,retain)HeaderView *headerView;
@end
@implementation GoodsCollectionView

-(void)reloadBannerData:(NSArray *)bannerList{
    [_headerView reloadBannerData:bannerList];
}

-(void)reloadGoodsData:(NSArray *)array{
    _list = array;
    [UIView performWithoutAnimation:^{
        [self reloadSections:[NSIndexSet indexSetWithIndex:1]];
    }];
}
-(instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout{
    self = [super initWithFrame:frame collectionViewLayout:layout];
    if (self) {
        self.delegate = self;
        self.dataSource = self;
        self.backgroundColor = [UIColor colorWithString:@"#ECECEC"];
        [self registerClass:[GoodsCollectionViewCell class] forCellWithReuseIdentifier:@"GoodsCollectionViewCell"];
        [self registerClass:[LikeCollectionViewCell class] forCellWithReuseIdentifier:@"LikeCollectionViewCell"];
        [self registerClass:[HeaderView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HeaderView"];
        [self registerClass:[LikeView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"LikeView"];
    }
    return self;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return (CGSize){[UIScreen mainScreen].bounds.size.width,297.5f};
    }else{
        return (CGSize){[UIScreen mainScreen].bounds.size.width,35.0f};
    }
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    if (kind == UICollectionElementKindSectionHeader) {
        if (indexPath.section == 0) {
            _headerView  = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"HeaderView" forIndexPath:indexPath];
            return _headerView;
        }else if(indexPath.section == 1){
            LikeView *view  = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"LikeView" forIndexPath:indexPath];
            return view;
        }
    }
    return nil;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        if (indexPath.row <=1) {
            return CGSizeMake((ScreenW - 1)/2, 135.0f);
        }else{
            return CGSizeMake((ScreenW - 3)/3, 135.0f);
        }
    }else{
        return CGSizeMake((ScreenW - 15)/2, 287.0f);
    }
}

//定义每个Section的四边间距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    if (section == 0) {
        return UIEdgeInsetsZero;
    }else{
        return UIEdgeInsetsMake(7, 3.5, 7, 3.5);//分别为上、左、下、右
    }
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    if (section == 0) {
        return 0;
    }else{
        return 7.0f;
    }
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    if (section == 0) {
        return 0;
    }else{
        return 7.0f;
    }
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        LikeCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"LikeCollectionViewCell" forIndexPath:indexPath];
        [cell setImage:[UIImage imageNamed:[NSString stringWithFormat:@"ad%ld",(long)indexPath.row+1]]];
        return cell;
    }else{
        GoodsCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"GoodsCollectionViewCell" forIndexPath:indexPath];
        [cell setModel:[_list safeObjectAtIndex:indexPath.row]];
        return cell;
    }
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
   return 2;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (section == 0) {
        return 5;
    }else{
        return _list?_list.count:0;
    }
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        if(indexPath.row == 1){
            XianShiScene *scene = [[XianShiScene alloc]init];
            [[URLNavigation navigation].currentNavigationViewController pushViewController:scene animated:YES];
        }else{
            CategoryListScene *scene = [[CategoryListScene alloc]init];
            if (indexPath.row == 0) {
                scene.type = 1;
            }else if (indexPath.row == 2) {
                scene.type = 10;
            }else if (indexPath.row == 3) {
                scene.type = 4;
            }else if (indexPath.row == 4) {
                scene.type = 2;
            }
            [[URLNavigation navigation].currentNavigationViewController pushViewController:scene animated:YES];
        }
    }else if (indexPath.section == 1){
        DetailScene *detail = [[DetailScene alloc]init];
        detail.model = [_list safeObjectAtIndex:indexPath.row];
        [[URLNavigation navigation].currentNavigationViewController pushViewController:detail animated:YES];
    }
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat y = scrollView.contentOffset.y;
    if(self.animationDelegate){
        if (y<=150.0f) {
            if(y>0){
                [self.animationDelegate animationWithPercent:y/150.0f];
            }else{
                [self.animationDelegate animationWithPercent:0.0f];
            }
        }else if(y<=300.0f){
             [self.animationDelegate animationWithPercent:1.0f];
        }
    }
}


@end
