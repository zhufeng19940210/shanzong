//
//  XianShiCell.h
//  lianmeng
//
//  Created by zhuchao on 2018/7/31.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GoodsListModel.h"

@interface XianShiCell : UITableViewCell
-(void)setModel:(GoodsModel *)model;
@end
