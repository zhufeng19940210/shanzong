//
//  RankListRequest.h
//  lianmeng
//
//  Created by zhuchao on 2018/6/26.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "Request.h"

@interface RankListRequest : Request
@property(nonatomic,retain)NSNumber *type;
@end
