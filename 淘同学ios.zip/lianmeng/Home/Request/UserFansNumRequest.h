//
//  UserFansNumRequest.h
//  lianmeng
//
//  Created by zhuchao on 2018/7/5.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "Request.h"

@interface UserFansNumRequest : Request
@property(nonatomic,retain)NSNumber *userId;
@end
