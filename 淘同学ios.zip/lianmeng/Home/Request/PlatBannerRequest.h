//
//  PlatBannerRequest.h
//  lianmeng
//
//  Created by zhuchao on 2018/7/29.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "Request.h"

@interface TaoBaoPlatBannerRequest : Request

@end
@interface JDPlatBannerRequest : Request

@end
