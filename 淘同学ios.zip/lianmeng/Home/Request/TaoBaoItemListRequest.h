//
//  TaoBaoItemListRequest.h
//  lianmeng
//
//  Created by zhuchao on 2018/6/17.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "Request.h"

@interface TaoBaoItemListRequest : Request
@property(nonatomic,retain)NSNumber *page;
@property(nonatomic,retain)NSNumber *cid;
@property(nonatomic,retain)NSNumber *userLevel;
@end
