//
//  PosterRequest.h
//  lianmeng
//
//  Created by zhuchao on 2018/8/6.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "Request.h"

@interface PosterRequest : Request
@property(nonatomic,retain)NSNumber *userId;
@end
