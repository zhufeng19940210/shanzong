//
//  MessageModel.h
//  lianmeng
//
//  Created by zhuchao on 2018/6/5.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "JSONModel.h"

@interface MessageModel : JSONModel

@end

@protocol MessageModel
@end


@interface MessageListModel : JSONModel

@end
