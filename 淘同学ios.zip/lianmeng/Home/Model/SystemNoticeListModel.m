//
//  SystemNoticeListModel.m
//  lianmeng
//
//  Created by zhuchao on 2018/7/1.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "SystemNoticeListModel.h"

@implementation SystemNoticeModel
@end
@implementation SystemNoticeListModel

@end
