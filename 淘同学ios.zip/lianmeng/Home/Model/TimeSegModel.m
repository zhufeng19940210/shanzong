//
//  TimeSegModel.m
//  lianmeng
//
//  Created by zhuchao on 2018/7/31.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "TimeSegModel.h"

@implementation TimeSegModel

@end

@implementation TimeSegListModel

@end
