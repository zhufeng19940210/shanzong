//
//  MomentListModel.m
//  lianmeng
//
//  Created by zhuchao on 2018/6/6.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "MomentListModel.h"

@implementation MomentModel
//+ (JSONKeyMapper *)keyMapper
//{
//    return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{
//                                                                  @"id": @"momentId",
//                                                                  }];
//}
@end


@implementation MomentListModel

@end
