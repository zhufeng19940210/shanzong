//
//  UpdateModel.m
//  lianmeng
//
//  Created by zhuchao on 2018/7/6.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "UpdateModel.h"

@implementation UpdateModel

@end
