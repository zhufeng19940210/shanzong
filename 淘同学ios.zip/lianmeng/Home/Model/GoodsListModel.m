//
//  GoodsListModel.m
//  lianmeng
//
//  Created by zhuchao on 2018/6/6.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "GoodsListModel.h"

@implementation GoodsModel
-(instancetype)init{
    self = [super init];
    if (self) {
        self.itemSale = @"0";
    }
    return self;
}
@end

@implementation GoodsListModel

@end
