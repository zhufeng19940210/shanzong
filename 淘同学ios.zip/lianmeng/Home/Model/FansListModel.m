//
//  FansList.m
//  lianmeng
//
//  Created by zhuchao on 2018/6/28.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "FansListModel.h"

@implementation FansModel

-(instancetype)init{
    self = [super init];
    if (self) {
        self.nickName = @"";
        self.username = @"";
    }

    return self;
}

@end

@implementation FansListModel

@end
