//
//  OrderNoticeListModel.m
//  lianmeng
//
//  Created by zhuchao on 2018/7/1.
//  Copyright © 2018年 zhuchao. All rights reserved.
//

#import "OrderNoticeListModel.h"

@implementation OrderNoticeModel
@end

@implementation OrderNoticeListModel

@end
