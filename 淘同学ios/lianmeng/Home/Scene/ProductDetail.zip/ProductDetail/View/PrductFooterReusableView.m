





//
//  PrductFooterReusableView.m
//  lianmeng
//
//  Created by zhufeng on 2019/1/3.
//  Copyright © 2019 zhuchao. All rights reserved.
//

#import "PrductFooterReusableView.h"

@implementation PrductFooterReusableView

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
